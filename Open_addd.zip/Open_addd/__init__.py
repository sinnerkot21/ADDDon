bl_info = {
    "name": "ADDDon",
    "author": "You",
    "version": (1, 0, 0),
    "blender": (3, 0, 0),
    "location": "3D View > Sidebar > ADDD",
    "description": "Adds a simple button 'ADDD' that opens a specific Google Docs link in the default browser",
    "category": "3D View",
}

import bpy
import webbrowser


# -------------------------------------------------
# Оператор — открывает ссылку в браузере
# -------------------------------------------------
class OPENADDD_OT_open_link(bpy.types.Operator):
    bl_idname = "wm.open_addd_link"
    bl_label = "ADDD"
    bl_description = "Open the ADDD Google Doc in your default web browser"

    # ссылка жёстко зашита здесь
    url: str = ("https://docs.google.com/document/d/1fv1vVbFbWbLIneNzAWLoO7z7e90vGzPCnPwQYSTcHYY/"
                "edit?tab=t.oqmafueyaha7#heading=h.fhggd7acdp7j")

    def execute(self, context):
        try:
            webbrowser.open(self.url, new=2)  # new=2 -> попытка открыть в новой вкладке
            self.report({'INFO'}, "ADDD: opened link in browser")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"ADDD: failed to open link: {e}")
            return {'CANCELLED'}


# -------------------------------------------------
# Панель в N-Panel (Sidebar) 3D View
# -------------------------------------------------
class OPENADDD_PT_panel(bpy.types.Panel):
    bl_label = "ADDD"
    bl_idname = "OPENADDD_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "ADDD"  # вкладка в N-panel

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.operator(OPENADDD_OT_open_link.bl_idname, text="ADDD", icon='URL')


# -------------------------------------------------
# Регистрация
# -------------------------------------------------
classes = (
    OPENADDD_OT_open_link,
    OPENADDD_PT_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
